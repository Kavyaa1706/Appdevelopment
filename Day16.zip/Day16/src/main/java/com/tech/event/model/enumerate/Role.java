package com.iamneo.ecom.model.enumerate;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public enum Role {
    ADMIN,
    CUSTOMER
}
